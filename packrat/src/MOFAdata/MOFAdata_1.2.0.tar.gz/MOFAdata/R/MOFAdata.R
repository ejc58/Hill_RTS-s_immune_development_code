#' MOFAdata: Data package for Multi-Omics Factor Analysis (MOFA)
#' 
#' @description The MOFAdata package provides a collection of datasets to accompany the
#' R package MOFA, where they are used to illustrate how to run MOFA and analyse its results.
#' Briefly, it contains multi-omics data for a bulk study on chronic lymphocytic leukemia and
#' a single cell scMT-seq study. For these two data sets, we also provide
#' pretrained MOFA objects to be used in downstream analysis with MOFA.
#' In addition, various gene sets are stored here, that can be useful when
#' performing feature set enrichment analysis in MOFA.
#' 
#' @details An overview of the datasets contained in this package can be found in the vignette "MOFAdata".
#' @docType package
#' @name MOFAdata
NULL