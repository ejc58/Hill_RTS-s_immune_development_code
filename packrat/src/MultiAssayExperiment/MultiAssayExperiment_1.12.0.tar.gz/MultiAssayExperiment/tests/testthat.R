library(testthat)
library(MultiAssayExperiment)

test_check("MultiAssayExperiment")
