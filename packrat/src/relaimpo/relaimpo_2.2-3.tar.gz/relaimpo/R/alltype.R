#alltype <- function(){c("lmg","pmvd","last", "first", "betasq", "pratt", "genizi", "car")}
alltype <- function(){c("lmg","last", "first", "betasq", "pratt", "genizi", "car")}

