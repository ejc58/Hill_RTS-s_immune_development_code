
globalVariables("pmvdcalc")