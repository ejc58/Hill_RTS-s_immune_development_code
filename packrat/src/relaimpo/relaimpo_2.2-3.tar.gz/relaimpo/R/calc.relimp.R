calc.relimp <- function(object, ...)
   UseMethod("calc.relimp")

